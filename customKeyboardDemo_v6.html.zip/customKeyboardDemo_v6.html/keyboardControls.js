// FOR THE KEY CLICKS AND KEYSTROKES

var k;
var message = "";
	
function checkKeyClick(){
	k = event.keyCode;
	showKeyClick(k);
	
	
}

function showKeyClick(kc){
		message = message + "&#" + kc + ";";
		document.getElementById("display_div").innerHTML = message;
	
	
	message=message +"&nbsp; <img src='letter_" + kc + ".png' width='75px'>";
	document.getElementById("display_div").innerHTML = message;
	
	
	
	
}